'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import Navbar from '@/components/Navbar';
import StatusPill from '@/components/StatusPill';
import { Users, Server as ServerIcon, Activity, Ban } from 'lucide-react';

interface AdminUser {
  id: string;
  email: string;
  username: string;
  role: 'USER' | 'ADMIN';
  suspended: boolean;
  maxServers: number;
  maxMemoryMb: number;
  maxDiskMb: number;
  maxCpuPercent: number;
  _count: { servers: number };
}

interface AdminServer {
  id: string;
  name: string;
  status: string;
  suspended: boolean;
  runtime: string;
  owner: { username: string; email: string };
}

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [servers, setServers] = useState<AdminServer[]>([]);
  const [tab, setTab] = useState<'users' | 'servers'>('users');
  const [editing, setEditing] = useState<AdminUser | null>(null);

  async function load() {
    const [s, u, sv] = await Promise.all([
      api.get('/admin/stats'),
      api.get('/admin/users'),
      api.get('/admin/servers'),
    ]);
    setStats(s.data);
    setUsers(u.data);
    setServers(sv.data);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleSuspend(user: AdminUser) {
    await api.patch(`/admin/users/${user.id}/quotas`, { suspended: !user.suspended });
    load();
  }

  async function saveQuotas() {
    if (!editing) return;
    await api.patch(`/admin/users/${editing.id}/quotas`, {
      maxServers: editing.maxServers,
      maxMemoryMb: editing.maxMemoryMb,
      maxDiskMb: editing.maxDiskMb,
      maxCpuPercent: editing.maxCpuPercent,
    });
    setEditing(null);
    load();
  }

  return (
    <div>
      <Navbar />
      <main className="max-w-6xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-semibold mb-8">Admin</h1>

        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            <Stat icon={<Users size={16} />} label="Users" value={stats.userCount} />
            <Stat icon={<ServerIcon size={16} />} label="Servers" value={stats.serverCount} />
            <Stat icon={<Activity size={16} />} label="Running" value={stats.runningCount} />
            <Stat icon={<Ban size={16} />} label="Suspended" value={stats.suspendedCount} />
          </div>
        )}

        <div className="flex gap-1 border-b border-base-700 mb-6">
          {(['users', 'servers'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 text-sm border-b-2 -mb-px capitalize ${
                tab === t ? 'border-signal-500 text-signal-500' : 'border-transparent text-[#8ea095]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === 'users' && (
          <div className="rounded-lg border border-base-700 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-base-900 text-[#8ea095] text-left">
                <tr>
                  <th className="px-4 py-2 font-normal">User</th>
                  <th className="px-4 py-2 font-normal">Role</th>
                  <th className="px-4 py-2 font-normal">Servers</th>
                  <th className="px-4 py-2 font-normal">Quotas</th>
                  <th className="px-4 py-2 font-normal"></th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-base-800">
                    <td className="px-4 py-3">
                      <p>{u.username}</p>
                      <p className="text-[#8ea095] text-xs">{u.email}</p>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">{u.role}</td>
                    <td className="px-4 py-3">
                      {u._count.servers} / {u.maxServers}
                    </td>
                    <td className="px-4 py-3 text-xs text-[#8ea095] font-mono">
                      {u.maxMemoryMb}MB · {u.maxCpuPercent}% · {u.maxDiskMb}MB
                    </td>
                    <td className="px-4 py-3 text-right space-x-3">
                      <button onClick={() => setEditing(u)} className="text-xs text-signal-500 hover:underline">
                        Edit
                      </button>
                      <button
                        onClick={() => toggleSuspend(u)}
                        className={`text-xs hover:underline ${u.suspended ? 'text-signal-500' : 'text-red-400'}`}
                      >
                        {u.suspended ? 'Unsuspend' : 'Suspend'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'servers' && (
          <div className="rounded-lg border border-base-700 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-base-900 text-[#8ea095] text-left">
                <tr>
                  <th className="px-4 py-2 font-normal">Server</th>
                  <th className="px-4 py-2 font-normal">Owner</th>
                  <th className="px-4 py-2 font-normal">Runtime</th>
                  <th className="px-4 py-2 font-normal">Status</th>
                </tr>
              </thead>
              <tbody>
                {servers.map((s) => (
                  <tr key={s.id} className="border-t border-base-800">
                    <td className="px-4 py-3">{s.name}</td>
                    <td className="px-4 py-3 text-[#8ea095]">{s.owner.username}</td>
                    <td className="px-4 py-3 font-mono text-xs">{s.runtime}</td>
                    <td className="px-4 py-3">
                      <StatusPill status={s.status as any} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {editing && (
        <div className="fixed inset-0 z-40 bg-black/60 flex items-center justify-center px-6">
          <div className="w-full max-w-sm rounded-lg border border-base-700 bg-base-900 p-6 space-y-4">
            <h2 className="text-lg font-medium">Quotas — {editing.username}</h2>
            <QuotaField label="Max servers" value={editing.maxServers} onChange={(v) => setEditing({ ...editing, maxServers: v })} />
            <QuotaField label="Max RAM (MB)" value={editing.maxMemoryMb} onChange={(v) => setEditing({ ...editing, maxMemoryMb: v })} />
            <QuotaField label="Max disk (MB)" value={editing.maxDiskMb} onChange={(v) => setEditing({ ...editing, maxDiskMb: v })} />
            <QuotaField label="Max CPU (%)" value={editing.maxCpuPercent} onChange={(v) => setEditing({ ...editing, maxCpuPercent: v })} />
            <div className="flex gap-2 pt-2">
              <button onClick={saveQuotas} className="flex-1 rounded-md bg-signal-500 text-base-950 font-medium py-2">
                Save
              </button>
              <button onClick={() => setEditing(null)} className="flex-1 rounded-md border border-base-700 py-2">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-lg border border-base-700 bg-base-900/60 p-4">
      <div className="flex items-center gap-2 text-[#8ea095] text-xs mb-2">
        {icon} {label}
      </div>
      <div className="text-2xl font-semibold font-mono">{value}</div>
    </div>
  );
}

function QuotaField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <label className="text-sm text-[#a9bdb2]">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value) || 0)}
        className="mt-1 w-full rounded-md bg-base-950 border border-base-700 px-3 py-2 outline-none focus:border-signal-500"
      />
    </div>
  );
}
