import type { Metadata } from 'next';
import './globals.css';
import ToastProvider from '@/components/ToastProvider';

export const metadata: Metadata = {
  title: 'Kerit Panel — Self-Hosted Bot Hosting',
  description: 'Deploy, manage, and monitor bots in isolated Docker containers.',
  icons: {
    icon: '/favicon.svg',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen bg-base-950 text-[#e7f2ec] antialiased">
        <ToastProvider />
        {children}
      </body>
    </html>
  );
}
