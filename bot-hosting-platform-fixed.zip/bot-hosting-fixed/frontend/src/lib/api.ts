import axios from 'axios';

export const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
export const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:4000';

export const api = axios.create({ baseURL: `${API_URL}/api` });

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (typeof window !== 'undefined' && err?.response?.status === 401) {
      localStorage.removeItem('token');
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  },
);

export type ServerStatus = 'INSTALLING' | 'OFFLINE' | 'RUNNING' | 'STOPPING' | 'SUSPENDED' | 'ERRORED';

export interface BotServer {
  id: string;
  name: string;
  description?: string;
  status: ServerStatus;
  runtime: 'NODEJS' | 'PYTHON';
  startupCommand?: string;
  suspended: boolean;
  autoRestart: boolean;
  memoryLimitMb: number;
  cpuLimitPercent: number;
  diskLimitMb: number;
  createdAt: string;
  envVars?: { key: string; value: string }[];
}
