import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as request from 'supertest';
import { AuthModule } from '../src/auth/auth.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { MailService } from '../src/common/mail/mail.service';

/**
 * Exercises the real HTTP layer (routing, global ValidationPipe, JWT guard)
 * for the auth flow, with only the two external dependencies mocked:
 * Prisma (no real database) and Mail (no real SMTP). This is an
 * integration/e2e test, not a unit test — it verifies the pieces wire
 * together correctly, not the internals of AuthService (see
 * auth.service.spec.ts for that).
 */
describe('Auth (e2e)', () => {
  let app: INestApplication;

  // Simple in-memory "table" so register -> login can be tested end to end
  // without a real database.
  const users: any[] = [];

  const prisma = {
    user: {
      findFirst: jest.fn(({ where }: any) => {
        const clauses = where.OR as any[];
        return Promise.resolve(
          users.find((u) => clauses.some((c) => (c.email && u.email === c.email) || (c.username && u.username === c.username))) || null,
        );
      }),
      findUnique: jest.fn(({ where }: any) =>
        Promise.resolve(users.find((u) => u.id === where.id || u.email === where.email) || null),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `u${users.length + 1}`, role: 'USER', sessionVersion: 0, suspended: false, ...data };
        users.push(user);
        return Promise.resolve(user);
      }),
    },
    verificationToken: { create: jest.fn().mockResolvedValue({}) },
  };

  beforeAll(async () => {
    process.env.JWT_SECRET = 'test-secret';

    const moduleRef = await Test.createTestingModule({
      imports: [AuthModule],
    })
      .overrideProvider(PrismaService)
      .useValue(prisma)
      .overrideProvider(MailService)
      .useValue({ sendVerificationEmail: jest.fn(), sendPasswordResetEmail: jest.fn() })
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: true }));
    app.setGlobalPrefix('api');
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects registration with an invalid payload (400)', async () => {
    await request(app.getHttpServer())
      .post('/api/auth/register')
      .send({ email: 'not-an-email', username: 'a', password: 'short' })
      .expect(400);
  });

  it('registers a new user and returns an access token', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/auth/register')
      .send({ email: 'e2e@example.com', username: 'e2euser', password: 'password123' })
      .expect(201);

    expect(res.body).toHaveProperty('accessToken');
    expect(typeof res.body.accessToken).toBe('string');
  });

  it('rejects duplicate registration with 409', async () => {
    await request(app.getHttpServer())
      .post('/api/auth/register')
      .send({ email: 'e2e@example.com', username: 'e2euser', password: 'password123' })
      .expect(409);
  });

  it('logs in with correct credentials and returns an access token', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/auth/login')
      .send({ email: 'e2e@example.com', password: 'password123' })
      .expect(201); // Nest POST default is 201 unless overridden

    expect(res.body).toHaveProperty('accessToken');
  });

  it('rejects login with the wrong password (401)', async () => {
    await request(app.getHttpServer())
      .post('/api/auth/login')
      .send({ email: 'e2e@example.com', password: 'wrong-password' })
      .expect(401);
  });

  it('rejects an unauthenticated request to a protected route', async () => {
    await request(app.getHttpServer()).get('/api/auth/me').expect(401);
  });

  it('allows a protected route with a valid bearer token', async () => {
    const login = await request(app.getHttpServer())
      .post('/api/auth/login')
      .send({ email: 'e2e@example.com', password: 'password123' });

    await request(app.getHttpServer())
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${login.body.accessToken}`)
      .expect(200);
  });
});
