import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

/**
 * Sends transactional email (verification, password reset). If no SMTP_HOST
 * is configured, falls back to logging the message (with the actual link) to
 * the console so the platform is fully usable in dev/self-hosted setups that
 * haven't wired up a mail provider yet.
 */
@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private transporter: nodemailer.Transporter | null = null;
  private readonly from = process.env.MAIL_FROM || 'Bot Hosting Platform <no-reply@localhost>';

  constructor() {
    if (process.env.SMTP_HOST) {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
        secure: process.env.SMTP_SECURE === 'true',
        auth: process.env.SMTP_USER
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined,
      });
    }
  }

  private async send(to: string, subject: string, html: string, textFallback: string) {
    if (!this.transporter) {
      this.logger.warn(
        `[dev-mail] SMTP not configured — logging email instead of sending.\nTo: ${to}\nSubject: ${subject}\n${textFallback}`,
      );
      return;
    }
    try {
      await this.transporter.sendMail({ from: this.from, to, subject, html, text: textFallback });
    } catch (err) {
      this.logger.error(`Failed to send email to ${to}: ${(err as Error).message}`);
    }
  }

  async sendVerificationEmail(to: string, link: string) {
    await this.send(
      to,
      'Verify your email',
      `<p>Welcome! Please verify your email by clicking the link below:</p><p><a href="${link}">${link}</a></p><p>This link expires in 24 hours.</p>`,
      `Verify your email: ${link} (expires in 24 hours)`,
    );
  }

  async sendPasswordResetEmail(to: string, link: string) {
    await this.send(
      to,
      'Reset your password',
      `<p>We received a request to reset your password. Click the link below to choose a new one:</p><p><a href="${link}">${link}</a></p><p>This link expires in 1 hour. If you didn't request this, you can safely ignore this email.</p>`,
      `Reset your password: ${link} (expires in 1 hour)`,
    );
  }
}
