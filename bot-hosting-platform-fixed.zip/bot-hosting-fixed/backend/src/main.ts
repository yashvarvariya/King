import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { cors: false });

  // Security headers (CSP kept permissive for the API-only surface; the
  // frontend, which actually serves HTML/JS, sets its own CSP via next.config.js).
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
    }),
  );

  app.enableCors({
    origin: process.env.CORS_ORIGIN?.split(',') || 'http://localhost:3000',
    credentials: true,
  });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
      // Strip anything not declared on the DTO *and* reject unknown fields,
      // which also blocks basic mass-assignment / prototype-pollution style
      // payloads from ever reaching a service method.
    }),
  );

  app.setGlobalPrefix('api', { exclude: ['/'] });

  const port = process.env.PORT ? parseInt(process.env.PORT) : 4000;
  await app.listen(port, '0.0.0.0');
  // eslint-disable-next-line no-console
  console.log(`Bot Hosting API listening on :${port}`);
}
bootstrap();
