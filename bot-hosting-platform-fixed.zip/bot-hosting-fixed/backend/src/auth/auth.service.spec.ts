import { Test } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { ConflictException, UnauthorizedException, BadRequestException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';
import { PrismaService } from '../prisma/prisma.service';
import { MailService } from '../common/mail/mail.service';

// bcrypt.hash/compare are CPU-bound and slow at real cost=12; stub them so
// unit tests stay fast and deterministic without weakening real security.
jest.mock('bcrypt', () => ({
  hash: jest.fn(async (pw: string) => `hashed:${pw}`),
  compare: jest.fn(async (pw: string, hash: string) => hash === `hashed:${pw}`),
}));

describe('AuthService', () => {
  let service: AuthService;
  let prisma: {
    user: any;
    verificationToken: any;
    passwordResetToken: any;
    $transaction: jest.Mock;
  };
  let mail: { sendVerificationEmail: jest.Mock; sendPasswordResetEmail: jest.Mock };

  beforeEach(async () => {
    prisma = {
      user: {
        findFirst: jest.fn(),
        findUnique: jest.fn(),
        findUniqueOrThrow: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
      },
      verificationToken: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn() },
      passwordResetToken: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn() },
      $transaction: jest.fn((ops: any[]) => Promise.all(ops)),
    };
    mail = { sendVerificationEmail: jest.fn(), sendPasswordResetEmail: jest.fn() };

    const module = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: prisma },
        { provide: MailService, useValue: mail },
        { provide: JwtService, useValue: { sign: jest.fn(() => 'signed.jwt.token') } },
      ],
    }).compile();

    service = module.get(AuthService);
  });

  afterEach(() => jest.clearAllMocks());

  describe('register', () => {
    it('creates a user, sends a verification email, and returns a token', async () => {
      prisma.user.findFirst.mockResolvedValue(null);
      prisma.user.create.mockResolvedValue({
        id: 'u1',
        email: 'a@b.com',
        role: 'USER',
        sessionVersion: 0,
      });

      const result = await service.register({ email: 'a@b.com', username: 'alice', password: 'password123' });

      expect(prisma.user.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ email: 'a@b.com', username: 'alice' }) }),
      );
      expect(mail.sendVerificationEmail).toHaveBeenCalledWith('a@b.com', expect.stringContaining('/verify-email?token='));
      expect(result).toEqual({ accessToken: 'signed.jwt.token' });
    });

    it('rejects when email or username is already taken', async () => {
      prisma.user.findFirst.mockResolvedValue({ id: 'existing' });

      await expect(
        service.register({ email: 'a@b.com', username: 'alice', password: 'password123' }),
      ).rejects.toBeInstanceOf(ConflictException);
      expect(prisma.user.create).not.toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('returns a token for valid credentials', async () => {
      prisma.user.findUnique.mockResolvedValue({
        id: 'u1',
        email: 'a@b.com',
        passwordHash: 'hashed:password123',
        suspended: false,
        role: 'USER',
        sessionVersion: 0,
      });

      const result = await service.login({ email: 'a@b.com', password: 'password123' });
      expect(result).toEqual({ accessToken: 'signed.jwt.token' });
    });

    it('rejects an unknown email', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      await expect(service.login({ email: 'nope@b.com', password: 'x' })).rejects.toBeInstanceOf(UnauthorizedException);
    });

    it('rejects an incorrect password', async () => {
      prisma.user.findUnique.mockResolvedValue({
        id: 'u1',
        passwordHash: 'hashed:correct',
        suspended: false,
        role: 'USER',
        sessionVersion: 0,
      });
      await expect(service.login({ email: 'a@b.com', password: 'wrong' })).rejects.toBeInstanceOf(UnauthorizedException);
    });

    it('rejects a suspended account even with correct credentials', async () => {
      prisma.user.findUnique.mockResolvedValue({
        id: 'u1',
        passwordHash: 'hashed:password123',
        suspended: true,
        role: 'USER',
        sessionVersion: 0,
      });
      await expect(service.login({ email: 'a@b.com', password: 'password123' })).rejects.toBeInstanceOf(
        UnauthorizedException,
      );
    });
  });

  describe('forgotPassword', () => {
    it('creates a reset token and emails it when the account exists', async () => {
      prisma.user.findUnique.mockResolvedValue({ id: 'u1', email: 'a@b.com' });
      const result = await service.forgotPassword({ email: 'a@b.com' });
      expect(prisma.passwordResetToken.create).toHaveBeenCalled();
      expect(mail.sendPasswordResetEmail).toHaveBeenCalled();
      expect(result).toEqual({ success: true });
    });

    it('returns success without leaking whether the account exists', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      const result = await service.forgotPassword({ email: 'unknown@b.com' });
      expect(prisma.passwordResetToken.create).not.toHaveBeenCalled();
      expect(mail.sendPasswordResetEmail).not.toHaveBeenCalled();
      expect(result).toEqual({ success: true });
    });
  });

  describe('resetPassword', () => {
    it('rejects an invalid or expired token', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue(null);
      await expect(service.resetPassword({ token: 'bad', newPassword: 'newpassword1' })).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('rejects an already-used token', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 't1',
        userId: 'u1',
        usedAt: new Date(),
        expiresAt: new Date(Date.now() + 60_000),
      });
      await expect(service.resetPassword({ token: 'used', newPassword: 'newpassword1' })).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('updates the password and bumps sessionVersion on success', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 't1',
        userId: 'u1',
        usedAt: null,
        expiresAt: new Date(Date.now() + 60_000),
      });

      const result = await service.resetPassword({ token: 'good', newPassword: 'newpassword1' });

      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: 'u1' },
          data: expect.objectContaining({ sessionVersion: { increment: 1 } }),
        }),
      );
      expect(result).toEqual({ success: true });
    });
  });

  describe('changePassword', () => {
    it('rejects an incorrect current password', async () => {
      prisma.user.findUniqueOrThrow.mockResolvedValue({ id: 'u1', passwordHash: 'hashed:correct' });
      await expect(
        service.changePassword('u1', { currentPassword: 'wrong', newPassword: 'newpassword1' }),
      ).rejects.toBeInstanceOf(UnauthorizedException);
    });

    it('updates the password, bumps sessionVersion, and re-issues a token', async () => {
      prisma.user.findUniqueOrThrow.mockResolvedValue({ id: 'u1', passwordHash: 'hashed:oldpass123' });
      prisma.user.update.mockResolvedValue({ id: 'u1', role: 'USER', sessionVersion: 1 });

      const result = await service.changePassword('u1', {
        currentPassword: 'oldpass123',
        newPassword: 'newpassword1',
      });

      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ sessionVersion: { increment: 1 } }) }),
      );
      expect(result).toEqual({ accessToken: 'signed.jwt.token' });
    });
  });

  describe('logoutAllSessions', () => {
    it('bumps sessionVersion and returns a fresh token', async () => {
      prisma.user.update.mockResolvedValue({ id: 'u1', role: 'USER', sessionVersion: 3 });
      const result = await service.logoutAllSessions('u1');
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({ where: { id: 'u1' }, data: { sessionVersion: { increment: 1 } } }),
      );
      expect(result).toEqual({ accessToken: 'signed.jwt.token' });
    });
  });

  describe('verifyEmail', () => {
    it('rejects an invalid, used, or expired token', async () => {
      prisma.verificationToken.findUnique.mockResolvedValue(null);
      await expect(service.verifyEmail({ token: 'bad' })).rejects.toBeInstanceOf(BadRequestException);
    });

    it('marks the user verified and the token used on success', async () => {
      prisma.verificationToken.findUnique.mockResolvedValue({
        id: 'v1',
        userId: 'u1',
        usedAt: null,
        expiresAt: new Date(Date.now() + 60_000),
      });

      const result = await service.verifyEmail({ token: 'good' });

      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({ where: { id: 'u1' }, data: { emailVerified: true } }),
      );
      expect(result).toEqual({ success: true });
    });
  });
});
