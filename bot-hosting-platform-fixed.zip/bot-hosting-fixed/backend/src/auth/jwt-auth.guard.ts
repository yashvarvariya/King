import { ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  handleRequest(err: any, user: any) {
    if (err || !user) {
      throw new UnauthorizedException('Invalid or expired token');
    }
    if (user.suspended) {
      throw new UnauthorizedException('Account suspended');
    }
    return user;
  }

  getRequest(context: ExecutionContext) {
    const type = context.getType();
    if (type === 'ws') {
      return context.switchToWs().getClient().handshake;
    }
    return super.getRequest(context);
  }
}
