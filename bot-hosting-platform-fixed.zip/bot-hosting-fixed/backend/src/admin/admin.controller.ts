import { Body, Controller, Get, Param, Patch, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { AdminService } from './admin.service';
import { UpdateQuotasDto } from './dto';

@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN')
@Controller('admin')
export class AdminController {
  constructor(private admin: AdminService) {}

  @Get('stats')
  stats() {
    return this.admin.stats();
  }

  @Get('users')
  users() {
    return this.admin.listUsers();
  }

  @Get('servers')
  servers() {
    return this.admin.listAllServers();
  }

  @Patch('users/:id/quotas')
  updateQuotas(@Param('id') id: string, @Body() dto: UpdateQuotasDto) {
    return this.admin.updateQuotas(id, dto);
  }

  @Patch('users/:id/role')
  setRole(@Param('id') id: string, @Body() body: { role: 'USER' | 'ADMIN' }) {
    return this.admin.setRole(id, body.role);
  }
}
