import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateQuotasDto } from './dto';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  async stats() {
    const [userCount, serverCount, runningCount, suspendedCount] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.server.count(),
      this.prisma.server.count({ where: { status: 'RUNNING' } }),
      this.prisma.server.count({ where: { suspended: true } }),
    ]);
    return { userCount, serverCount, runningCount, suspendedCount };
  }

  listUsers() {
    return this.prisma.user.findMany({
      select: {
        id: true, email: true, username: true, role: true, suspended: true,
        maxServers: true, maxMemoryMb: true, maxDiskMb: true, maxCpuPercent: true,
        createdAt: true, _count: { select: { servers: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  listAllServers() {
    return this.prisma.server.findMany({
      include: { owner: { select: { username: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async updateQuotas(userId: string, dto: UpdateQuotasDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');
    return this.prisma.user.update({ where: { id: userId }, data: dto });
  }

  async setRole(userId: string, role: 'USER' | 'ADMIN') {
    return this.prisma.user.update({ where: { id: userId }, data: { role } });
  }
}
