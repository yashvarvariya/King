import { IsBoolean, IsInt, IsOptional, Min } from 'class-validator';

export class UpdateQuotasDto {
  @IsOptional() @IsInt() @Min(0)
  maxServers?: number;

  @IsOptional() @IsInt() @Min(64)
  maxMemoryMb?: number;

  @IsOptional() @IsInt() @Min(100)
  maxDiskMb?: number;

  @IsOptional() @IsInt() @Min(10)
  maxCpuPercent?: number;

  @IsOptional() @IsBoolean()
  suspended?: boolean;
}
