import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import * as fs from 'fs/promises';
import * as fsSync from 'fs';
import * as path from 'path';
import * as unzipper from 'unzipper';
import archiver from 'archiver';
import { ServersService } from '../servers/servers.service';

@Injectable()
export class FilesService {
  constructor(private serversService: ServersService) {}

  /** Resolves a user-supplied relative path safely within the server's root, blocking traversal. */
  private async resolvePath(serverId: string, userId: string, relativePath: string, isAdmin = false) {
    const server = await this.serversService.findOwned(serverId, userId, isAdmin);
    const root = this.serversService.hostPathFor(server);
    const normalized = path.normalize(path.join(root, relativePath || '.'));

    if (!normalized.startsWith(path.resolve(root))) {
      throw new BadRequestException('Invalid path');
    }
    return { root, absolute: normalized };
  }

  async list(serverId: string, userId: string, relativePath: string, isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    if (!fsSync.existsSync(absolute)) throw new NotFoundException('Path not found');

    const entries = await fs.readdir(absolute, { withFileTypes: true });
    const items = await Promise.all(
      entries.map(async (entry) => {
        const full = path.join(absolute, entry.name);
        const stat = await fs.stat(full);
        return {
          name: entry.name,
          type: entry.isDirectory() ? 'directory' : 'file',
          sizeBytes: entry.isDirectory() ? 0 : stat.size,
          modifiedAt: stat.mtime,
        };
      }),
    );

    // directories first, then alphabetical
    items.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'directory' ? -1 : 1));
    return items;
  }

  async readFile(serverId: string, userId: string, relativePath: string, isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    if (!fsSync.existsSync(absolute)) throw new NotFoundException('File not found');
    const stat = await fs.stat(absolute);
    if (stat.isDirectory()) throw new BadRequestException('Cannot read a directory as a file');
    if (stat.size > 5 * 1024 * 1024) throw new BadRequestException('File too large to edit in-browser (5MB max)');
    return fs.readFile(absolute, 'utf-8');
  }

  async writeFile(serverId: string, userId: string, relativePath: string, content: string, isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    await fs.mkdir(path.dirname(absolute), { recursive: true });
    await fs.writeFile(absolute, content, 'utf-8');
    return { success: true };
  }

  async createEntry(serverId: string, userId: string, relativePath: string, type: 'file' | 'directory', isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    if (fsSync.existsSync(absolute)) throw new BadRequestException('Already exists');
    if (type === 'directory') {
      await fs.mkdir(absolute, { recursive: true });
    } else {
      await fs.mkdir(path.dirname(absolute), { recursive: true });
      await fs.writeFile(absolute, '');
    }
    return { success: true };
  }

  async rename(serverId: string, userId: string, relativePath: string, newName: string, isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    if (!fsSync.existsSync(absolute)) throw new NotFoundException('Path not found');
    const dest = path.join(path.dirname(absolute), newName);
    await fs.rename(absolute, dest);
    return { success: true };
  }

  async remove(serverId: string, userId: string, relativePath: string, isAdmin = false) {
    const { absolute, root } = await this.resolvePath(serverId, userId, relativePath, isAdmin);
    if (absolute === path.resolve(root)) throw new BadRequestException('Cannot delete server root');
    await fs.rm(absolute, { recursive: true, force: true });
    return { success: true };
  }

  async extractZip(serverId: string, userId: string, zipBuffer: Buffer, destRelativePath = '.', isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, destRelativePath, isAdmin);
    await fs.mkdir(absolute, { recursive: true });

    const directory = await unzipper.Open.buffer(zipBuffer);
    for (const file of directory.files) {
      const target = path.join(absolute, file.path);
      if (!target.startsWith(path.resolve(absolute))) continue; // zip-slip protection
      if (file.type === 'Directory') {
        await fs.mkdir(target, { recursive: true });
      } else {
        await fs.mkdir(path.dirname(target), { recursive: true });
        const content = await file.buffer();
        await fs.writeFile(target, content);
      }
    }
    return { success: true, filesExtracted: directory.files.length };
  }

  async saveUpload(serverId: string, userId: string, destRelativePath: string, fileName: string, buffer: Buffer, isAdmin = false) {
    const { absolute } = await this.resolvePath(serverId, userId, path.join(destRelativePath, fileName), isAdmin);
    await fs.mkdir(path.dirname(absolute), { recursive: true });
    await fs.writeFile(absolute, buffer);
    return { success: true };
  }

  /** Streams the whole server directory as a zip archive (used by backups + manual "download all"). */
  archiveDirectory(rootDir: string) {
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.directory(rootDir, false);
    archive.finalize();
    return archive;
  }
}
