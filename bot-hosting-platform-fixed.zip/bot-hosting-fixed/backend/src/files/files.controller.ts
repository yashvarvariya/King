import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { FilesService } from './files.service';

@UseGuards(JwtAuthGuard)
@Controller('servers/:serverId/files')
export class FilesController {
  constructor(private files: FilesService) {}

  private isAdmin(user: any) {
    return user.role === 'ADMIN';
  }

  @Get()
  list(@Param('serverId') serverId: string, @Query('path') path: string = '.', @CurrentUser() user: any) {
    return this.files.list(serverId, user.id, path, this.isAdmin(user));
  }

  @Get('content')
  read(@Param('serverId') serverId: string, @Query('path') path: string, @CurrentUser() user: any) {
    return this.files.readFile(serverId, user.id, path, this.isAdmin(user)).then((content) => ({ content }));
  }

  @Post('content')
  write(
    @Param('serverId') serverId: string,
    @Body() body: { path: string; content: string },
    @CurrentUser() user: any,
  ) {
    return this.files.writeFile(serverId, user.id, body.path, body.content, this.isAdmin(user));
  }

  @Post('create')
  create(
    @Param('serverId') serverId: string,
    @Body() body: { path: string; type: 'file' | 'directory' },
    @CurrentUser() user: any,
  ) {
    return this.files.createEntry(serverId, user.id, body.path, body.type, this.isAdmin(user));
  }

  @Post('rename')
  rename(
    @Param('serverId') serverId: string,
    @Body() body: { path: string; newName: string },
    @CurrentUser() user: any,
  ) {
    return this.files.rename(serverId, user.id, body.path, body.newName, this.isAdmin(user));
  }

  @Delete()
  remove(@Param('serverId') serverId: string, @Query('path') path: string, @CurrentUser() user: any) {
    return this.files.remove(serverId, user.id, path, this.isAdmin(user));
  }

  @Post('upload')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 512 * 1024 * 1024 } }))
  async upload(
    @Param('serverId') serverId: string,
    @Query('path') destPath: string = '.',
    @UploadedFile() file: Express.Multer.File,
    @CurrentUser() user: any,
  ) {
    if (!file) throw new BadRequestException('No file uploaded');
    return this.files.saveUpload(serverId, user.id, destPath, file.originalname, file.buffer, this.isAdmin(user));
  }

  @Post('upload-zip')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 512 * 1024 * 1024 } }))
  async uploadZip(
    @Param('serverId') serverId: string,
    @Query('path') destPath: string = '.',
    @UploadedFile() file: Express.Multer.File,
    @CurrentUser() user: any,
  ) {
    if (!file) throw new BadRequestException('No ZIP uploaded');
    return this.files.extractZip(serverId, user.id, file.buffer, destPath, this.isAdmin(user));
  }
}
