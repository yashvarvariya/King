import { Module } from '@nestjs/common';
import { ServersService } from './servers.service';
import { ServersController } from './servers.controller';
import { DockerModule } from '../docker/docker.module';
import { AutoRestartTask } from './auto-restart.task';

@Module({
  imports: [DockerModule],
  providers: [ServersService, AutoRestartTask],
  controllers: [ServersController],
  exports: [ServersService],
})
export class ServersModule {}
