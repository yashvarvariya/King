import Link from 'next/link';
import { Terminal, Box, Cpu, ShieldCheck } from 'lucide-react';

export default function Home() {
  return (
    <main className="relative overflow-hidden">
      <div className="absolute inset-0 [background-image:linear-gradient(#161f1b_1px,transparent_1px),linear-gradient(90deg,#161f1b_1px,transparent_1px)] [background-size:48px_48px] opacity-40" />

      <div className="relative max-w-5xl mx-auto px-6 pt-24 pb-16">
        <div className="flex items-center gap-2 text-sm font-mono text-signal-500 mb-6">
          <Terminal size={16} />
          <span>self-hosted · docker-isolated · no pterodactyl</span>
        </div>

        <h1 className="text-5xl md:text-6xl font-semibold tracking-tight leading-[1.05]">
          Host bots the way<br />
          <span className="text-signal-500">you actually control.</span>
        </h1>

        <p className="mt-6 text-lg text-[#a9bdb2] max-w-xl">
          Every server you deploy runs in its own isolated Docker container — Node.js or
          Python, ZIP upload or a GitHub repo, live console over WebSocket, and real
          CPU/RAM/disk numbers. No third-party panel dependency.
        </p>

        <div className="mt-10 flex gap-4">
          <Link
            href="/register"
            className="px-6 py-3 rounded-md bg-signal-500 text-base-950 font-medium hover:bg-signal-400 transition-colors"
          >
            Create account
          </Link>
          <Link
            href="/login"
            className="px-6 py-3 rounded-md border border-base-600 hover:border-signal-500 transition-colors"
          >
            Sign in
          </Link>
        </div>

        <div className="mt-20 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <Feature icon={<Box size={20} />} title="Container isolation" desc="One dedicated Docker container per server, capped on CPU, RAM, and disk." />
          <Feature icon={<Cpu size={20} />} title="Live everything" desc="Console output, resource graphs, and process control stream over WebSocket." />
          <Feature icon={<ShieldCheck size={20} />} title="You own the stack" desc="Nginx, NestJS, Postgres, Redis, Next.js — all in your docker-compose." />
        </div>
      </div>
    </main>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-lg border border-base-700 bg-base-900/60 p-5">
      <div className="text-signal-500 mb-3">{icon}</div>
      <div className="font-medium mb-1">{title}</div>
      <div className="text-sm text-[#8ea095]">{desc}</div>
    </div>
  );
}
