'use client';

import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { api, setStoredToken } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import Navbar from '@/components/Navbar';
import toast from 'react-hot-toast';

export default function AccountPage() {
  const router = useRouter();
  const { user, loading: userLoading } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [loggingOutAll, setLoggingOutAll] = useState(false);

  async function onChangePassword(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }
    setSaving(true);
    try {
      const res = await api.post('/auth/change-password', { currentPassword, newPassword });
      setStoredToken(res.data.accessToken);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      toast.success('Password updated');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Could not change password');
    } finally {
      setSaving(false);
    }
  }

  async function onLogoutAllDevices() {
    setLoggingOutAll(true);
    try {
      const res = await api.post('/auth/logout-all');
      setStoredToken(res.data.accessToken);
      toast.success('Every other session has been logged out');
    } catch {
      toast.error('Could not log out other devices');
    } finally {
      setLoggingOutAll(false);
    }
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-10 space-y-10">
        <div>
          <h1 className="text-2xl font-semibold">Account</h1>
          {!userLoading && user && <p className="text-sm text-[#8ea095] mt-1">{user.email}</p>}
        </div>

        <section className="space-y-4">
          <h2 className="text-lg font-medium">Change password</h2>
          <form onSubmit={onChangePassword} className="space-y-4">
            <div>
              <label className="text-sm text-[#a9bdb2]">Current password</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="mt-1 w-full rounded-md bg-base-900 border border-base-700 px-3 py-2 outline-none focus:border-signal-500"
              />
            </div>
            <div>
              <label className="text-sm text-[#a9bdb2]">New password</label>
              <input
                type="password"
                required
                minLength={8}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="8+ characters"
                className="mt-1 w-full rounded-md bg-base-900 border border-base-700 px-3 py-2 outline-none focus:border-signal-500"
              />
            </div>
            <div>
              <label className="text-sm text-[#a9bdb2]">Confirm new password</label>
              <input
                type="password"
                required
                minLength={8}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 w-full rounded-md bg-base-900 border border-base-700 px-3 py-2 outline-none focus:border-signal-500"
              />
            </div>

            {error && <p className="text-sm text-red-400">{error}</p>}

            <button
              type="submit"
              disabled={saving}
              className="rounded-md bg-signal-500 text-base-950 font-medium px-4 py-2 hover:bg-signal-400 transition-colors disabled:opacity-60"
            >
              {saving ? 'Saving…' : 'Update password'}
            </button>
          </form>
        </section>

        <section className="space-y-3 border-t border-base-700 pt-8">
          <h2 className="text-lg font-medium">Sessions</h2>
          <p className="text-sm text-[#8ea095]">
            Log out of every other browser or device signed in to your account. This browser will stay signed in.
          </p>
          <button
            onClick={onLogoutAllDevices}
            disabled={loggingOutAll}
            className="rounded-md border border-base-700 px-4 py-2 text-sm hover:border-red-400 hover:text-red-400 transition-colors disabled:opacity-60"
          >
            {loggingOutAll ? 'Logging out other devices…' : 'Log out all other devices'}
          </button>
        </section>
      </div>
    </main>
  );
}
