import type { Metadata } from 'next';
import './globals.css';
import ToastProvider from '@/components/ToastProvider';
import BrandingProvider from '@/lib/branding';
import AppGate from '@/components/AppGate';

// Static fallback only — the real, branded title/favicon are applied on the
// client by BrandingProvider once `/branding` loads (see lib/branding.tsx),
// since this platform's name/icon are admin-configurable at runtime rather
// than build time.
export const metadata: Metadata = {
  title: 'Bot Hosting Panel',
  description: 'Deploy, manage, and monitor bots in isolated Docker containers.',
  icons: {
    icon: '/favicon.svg',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen bg-base-950 text-[#e7f2ec] antialiased">
        <ToastProvider />
        <BrandingProvider>
          <AppGate>{children}</AppGate>
        </BrandingProvider>
      </body>
    </html>
  );
}
