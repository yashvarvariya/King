export interface AdminStats {
  totalUsers: number;
  totalServers: number;
  runningServers: number;
  stoppedServers: number;
  premiumUsers: number;
  freeUsers: number;
  suspendedUsers: number;
}

export interface AdminUser {
  id: string;
  email: string;
  username: string;
  role: 'USER' | 'ADMIN';
  suspended: boolean;
  emailVerified: boolean;
  isPremium: boolean;
  premiumSince: string | null;
  lastActiveAt: string;
  maxServers: number;
  maxMemoryMb: number;
  maxDiskMb: number;
  maxCpuPercent: number;
  backupLimit: number;
  createdAt: string;
  _count: { servers: number };
}

export type AdminServerStatus = 'INSTALLING' | 'OFFLINE' | 'RUNNING' | 'STOPPING' | 'SUSPENDED' | 'ERRORED';

export interface AdminServer {
  id: string;
  name: string;
  description?: string | null;
  status: AdminServerStatus;
  runtime: 'NODEJS' | 'PYTHON';
  startupCommand?: string | null;
  suspended: boolean;
  autoRestart: boolean;
  memoryLimitMb: number;
  cpuLimitPercent: number;
  diskLimitMb: number;
  createdAt: string;
  owner: { username: string; email: string; isPremium: boolean };
}

export interface QuotaFields {
  maxServers: number;
  maxMemoryMb: number;
  maxDiskMb: number;
  maxCpuPercent: number;
  backupLimit: number;
}

export interface ServerResourceFields {
  memoryLimitMb: number;
  cpuLimitPercent: number;
  diskLimitMb: number;
}
