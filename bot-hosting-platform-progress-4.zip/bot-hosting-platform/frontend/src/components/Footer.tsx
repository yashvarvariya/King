'use client';

import { useBranding } from '@/lib/branding';
import { MessageCircle, Mail } from 'lucide-react';

export default function Footer() {
  const branding = useBranding();
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-base-700 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#8ea095]">
        <p>
          © {year} {branding.hostingName}. {branding.footerText}
        </p>
        <div className="flex items-center gap-4">
          {branding.supportEmail && (
            <a
              href={`mailto:${branding.supportEmail}`}
              className="flex items-center gap-1.5 hover:text-signal-500 transition-colors"
            >
              <Mail size={13} /> {branding.supportEmail}
            </a>
          )}
          {branding.discordInvite && (
            <a
              href={branding.discordInvite}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-signal-500 transition-colors"
            >
              <MessageCircle size={13} /> Discord
            </a>
          )}
        </div>
      </div>
    </footer>
  );
}
