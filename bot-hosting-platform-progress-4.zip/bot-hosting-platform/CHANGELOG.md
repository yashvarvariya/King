# Changelog

All notable changes to this project are documented here. Format loosely
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- Part 8: full documentation set (README, INSTALL, DEPLOYMENT, ENVIRONMENT,
  API, SECURITY, BACKUPS, CONTRIBUTING, this changelog, LICENSE).
- Part 9: project-wide cleanup/audit pass.

## [1.0.0] — Production infrastructure

### Added (CI/CD)
- GitHub Actions CI pipeline: install, lint, type-check, build (frontend +
  backend), unit tests, integration tests, e2e tests, Docker build
  validation, and Docker Compose config validation.
- CodeQL static analysis workflow.
- Dependency vulnerability scanning workflow.
- Dependabot configuration for npm and GitHub Actions dependency updates.
- Release workflow for tagged versions (builds and publishes versioned
  Docker images).

### Added (Production infrastructure)
- Production Nginx config: HTTPS via Let's Encrypt/certbot, HTTP→HTTPS
  redirect, security headers, gzip, cache headers for static assets.
- `docker-compose.prod.yml`: hardened non-root images, per-service resource
  limits, healthchecks, log rotation, certbot renewal sidecar, reduced
  attack surface (only Nginx publishes ports).
- Production Dockerfiles (`Dockerfile.prod`) for backend and frontend:
  multi-stage builds, non-root users.
- Health check endpoints: `GET /api/health` (liveness) and
  `GET /api/health/ready` (readiness — checks Postgres, Redis, Docker
  socket).
- `.dockerignore` for both backend and frontend.
- ESLint + Prettier configs for both backend and frontend.
- `deploy/logrotate/` config and `deploy/crontab.example`.
- `scripts/backup-cron.sh` — infrastructure-level (DB + server files)
  backup script with retention pruning.
- `scripts/render-nginx-prod.sh` — templates the production Nginx config
  with the deployment's real domain.

### Fixed
- `FRONTEND_URL` and `SMTP_*` environment variables were read by the backend
  (`auth.service.ts`, `mail.service.ts`) but were never forwarded by
  `docker-compose.yml`, silently breaking password-reset/verification email
  links and outbound mail in any Docker-based deployment. Added to both
  `.env.example` and `docker-compose.yml`.

## [0.x] — Original application (Parts 1–5)

- Initial NestJS backend + Next.js frontend: auth, server lifecycle
  management, Docker-based bot isolation, file manager, live console over
  WebSocket, resource stats, backups, admin dashboard.
- Frontend polish: toast notifications, skeleton loaders, error boundaries,
  responsive layout, branding.
- File manager rewrite: drag-and-drop upload, multi-file upload with
  progress, context menu, keyboard shortcuts, inline rename/delete.
- Console rewrite: per-server command history, auto-reconnect, colored log
  levels, scroll-lock with "jump to latest", log search, log download.
- Initial backend/frontend test suites (Jest, ts-jest, Testing Library,
  supertest for e2e).
