import { IsString, IsOptional, IsIn, MinLength, MaxLength, IsBoolean, IsObject, IsInt, Min, Max } from 'class-validator';

export class CreateServerDto {
  @IsString() @MinLength(2) @MaxLength(50)
  name!: string;

  @IsOptional() @IsString() @MaxLength(280)
  description?: string;

  @IsIn(['NODEJS', 'PYTHON'])
  runtime!: 'NODEJS' | 'PYTHON';

  @IsOptional() @IsString()
  startupCommand?: string;
}

export class RenameServerDto {
  @IsString() @MinLength(2) @MaxLength(50)
  name!: string;
}

export class UpdateSettingsDto {
  @IsOptional() @IsString()
  startupCommand?: string;

  @IsOptional() @IsBoolean()
  autoRestart?: boolean;

  @IsOptional() @IsBoolean()
  autoBackupEnabled?: boolean;

  @IsOptional() @IsInt() @Min(1) @Max(30)
  backupRetention?: number;
}

export class UpdateEnvDto {
  @IsObject()
  env!: Record<string, string>;
}

export class ImportGithubDto {
  @IsString()
  repoUrl!: string;

  @IsOptional() @IsString()
  branch?: string;
}
