import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Patch,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { BrandingService } from './branding.service';
import { UpdateBrandingDto } from './dto';

const ALLOWED_IMAGE_MIMES = new Set(['image/png', 'image/jpeg', 'image/svg+xml', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/webp']);
const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB — plenty for a logo/favicon

@Controller('branding')
export class BrandingController {
  constructor(private branding: BrandingService) {}

  // Public and unauthenticated on purpose: the login/register pages and the
  // maintenance screen all need this before any session exists.
  @Get()
  get() {
    return this.branding.get();
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Patch()
  update(@Body() dto: UpdateBrandingDto) {
    return this.branding.update(dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Post('upload/logo')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_IMAGE_BYTES } }))
  async uploadLogo(@UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    if (!ALLOWED_IMAGE_MIMES.has(file.mimetype)) {
      throw new BadRequestException('Unsupported image type');
    }
    return this.branding.saveUploadedImage('logo', file.buffer, file.originalname);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Post('upload/favicon')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_IMAGE_BYTES } }))
  async uploadFavicon(@UploadedFile() file: Express.Multer.File) {
    if (!file) throw new BadRequestException('No file uploaded');
    if (!ALLOWED_IMAGE_MIMES.has(file.mimetype)) {
      throw new BadRequestException('Unsupported image type');
    }
    return this.branding.saveUploadedImage('favicon', file.buffer, file.originalname);
  }
}
