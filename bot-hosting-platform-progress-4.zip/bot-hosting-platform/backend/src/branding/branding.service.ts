import { Injectable } from '@nestjs/common';
import { Branding } from '@prisma/client';
import * as fs from 'fs/promises';
import * as path from 'path';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateBrandingDto } from './dto';

const SINGLETON_ID = 'singleton';
const CACHE_TTL_MS = 5_000;

// Where uploaded branding images (logo/favicon) are written on disk. Served
// back out via express.static('/uploads', ...) — see main.ts. Kept separate
// from SERVERS_ROOT/BACKUPS_ROOT (bot data) on purpose: this is small,
// platform-owned static content, not user bot data.
const UPLOADS_ROOT = process.env.BRANDING_UPLOADS_DIR || path.join(process.cwd(), 'uploads', 'branding');

@Injectable()
export class BrandingService {
  private cache: { value: Branding; expiresAt: number } | null = null;

  constructor(private prisma: PrismaService) {}

  /** Returns the branding row, creating the default one on first ever call. */
  async get(): Promise<Branding> {
    const existing = await this.prisma.branding.findUnique({ where: { id: SINGLETON_ID } });
    if (existing) return existing;
    return this.prisma.branding.create({ data: { id: SINGLETON_ID } });
  }

  /**
   * Cached read used by hot paths (the global access guard runs on every
   * request) so branding/maintenance-mode checks don't cost a DB round trip
   * per request. Cache is short-lived and is also busted immediately on
   * update() so admin changes still apply "live" within a few seconds.
   */
  async getCached(): Promise<Branding> {
    if (this.cache && this.cache.expiresAt > Date.now()) return this.cache.value;
    const value = await this.get();
    this.cache = { value, expiresAt: Date.now() + CACHE_TTL_MS };
    return value;
  }

  async update(dto: UpdateBrandingDto): Promise<Branding> {
    await this.get(); // ensure the row exists
    const updated = await this.prisma.branding.update({ where: { id: SINGLETON_ID }, data: dto });
    this.cache = { value: updated, expiresAt: Date.now() + CACHE_TTL_MS };
    return updated;
  }

  async setMaintenanceMode(enabled: boolean): Promise<Branding> {
    return this.update({ maintenanceMode: enabled });
  }

  /**
   * Saves an uploaded logo/favicon image to disk and points the matching
   * branding field (logoUrl/faviconUrl) at its public URL path. Returns the
   * updated branding row.
   */
  async saveUploadedImage(
    kind: 'logo' | 'favicon',
    buffer: Buffer,
    originalName: string,
  ): Promise<Branding> {
    await fs.mkdir(UPLOADS_ROOT, { recursive: true });

    const ext = path.extname(originalName).toLowerCase() || '.png';
    const safeExt = /^\.[a-z0-9]{2,5}$/.test(ext) ? ext : '.png';
    const fileName = `${kind}-${crypto.randomBytes(8).toString('hex')}${safeExt}`;
    await fs.writeFile(path.join(UPLOADS_ROOT, fileName), buffer);

    const publicUrl = `/uploads/branding/${fileName}`;
    return this.update(kind === 'logo' ? { logoUrl: publicUrl } : { faviconUrl: publicUrl });
  }
}
