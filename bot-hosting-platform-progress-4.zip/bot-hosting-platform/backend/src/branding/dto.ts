import { IsBoolean, IsOptional, IsString, MaxLength } from 'class-validator';

// Free-text/URL fields intentionally use plain @IsString (not @IsUrl) so an
// admin can paste a bare domain, a relative path, or clear a field with an
// empty string without fighting strict URL validation.
export class UpdateBrandingDto {
  @IsOptional() @IsString() @MaxLength(80)
  hostingName?: string;

  @IsOptional() @IsString() @MaxLength(500)
  logoUrl?: string;

  @IsOptional() @IsString() @MaxLength(500)
  faviconUrl?: string;

  @IsOptional() @IsString() @MaxLength(80)
  browserTitle?: string;

  @IsOptional() @IsString() @MaxLength(200)
  footerText?: string;

  @IsOptional() @IsString() @MaxLength(300)
  discordInvite?: string;

  @IsOptional() @IsString() @MaxLength(120)
  supportEmail?: string;

  @IsOptional() @IsString() @MaxLength(20)
  themeColor?: string;

  @IsOptional() @IsString() @MaxLength(20)
  secondaryThemeColor?: string;

  @IsOptional() @IsString() @MaxLength(500)
  backgroundImageUrl?: string;

  @IsOptional() @IsBoolean()
  maintenanceMode?: boolean;
}
