import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async me(userId: string) {
    const { passwordHash, ...user } = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    return user;
  }

  async usage(userId: string) {
    const servers = await this.prisma.server.findMany({ where: { ownerId: userId } });
    return {
      serverCount: servers.length,
      runningCount: servers.filter((s) => s.status === 'RUNNING').length,
    };
  }
}
