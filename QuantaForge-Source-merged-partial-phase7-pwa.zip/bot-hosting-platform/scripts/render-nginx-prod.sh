#!/usr/bin/env bash
# Renders nginx/nginx.prod.conf -> nginx/nginx.prod.rendered.conf with
# ${SERVER_NAME} substituted for your real domain. Run this once (and again
# any time you change SERVER_NAME) before `docker compose -f
# docker-compose.prod.yml up`.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="$ROOT_DIR/.env"

if [ -f "$ENV_FILE" ]; then
  # shellcheck disable=SC1090
  set -a && source "$ENV_FILE" && set +a
fi

if [ -z "${SERVER_NAME:-}" ]; then
  echo "ERROR: SERVER_NAME is not set. Add SERVER_NAME=yourdomain.com to .env" >&2
  exit 1
fi

if ! command -v envsubst >/dev/null 2>&1; then
  echo "ERROR: envsubst not found. Install gettext-base (Debian/Ubuntu: apt install gettext-base)." >&2
  exit 1
fi

SRC="$ROOT_DIR/nginx/nginx.prod.conf"
DEST="$ROOT_DIR/nginx/nginx.prod.rendered.conf"

SERVER_NAME="$SERVER_NAME" envsubst '${SERVER_NAME}' < "$SRC" > "$DEST"

echo "Rendered $DEST for server_name: $SERVER_NAME"
echo "docker-compose.prod.yml mounts this rendered file automatically."
