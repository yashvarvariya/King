#!/usr/bin/env bash
# Run once on the host before `docker compose up` (or re-run if you change
# SERVERS_ROOT / BACKUPS_ROOT in .env). Creates the bind-mount directories
# that both the API container and the host Docker daemon need to agree on.
set -euo pipefail

ENV_FILE="$(dirname "$0")/../.env"
if [ -f "$ENV_FILE" ]; then
  # shellcheck disable=SC1090
  source "$ENV_FILE"
fi

SERVERS_ROOT="${SERVERS_ROOT:-/srv/bot-hosting/servers}"
BACKUPS_ROOT="${BACKUPS_ROOT:-/srv/bot-hosting/backups}"

echo "Creating $SERVERS_ROOT and $BACKUPS_ROOT ..."
sudo mkdir -p "$SERVERS_ROOT" "$BACKUPS_ROOT"
sudo chmod 755 "$SERVERS_ROOT" "$BACKUPS_ROOT"

echo "Done. You can now run: docker compose up -d --build"
